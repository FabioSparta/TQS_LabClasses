# JUnit5 with Allure reports example

With this example, you can execute the JUnit 5 tests defined in the project and get the Allure report in a easy way. With Maven:

```
mvn test allure:serve
```

... or with Gradle:

```
gradle test allureServe
```
